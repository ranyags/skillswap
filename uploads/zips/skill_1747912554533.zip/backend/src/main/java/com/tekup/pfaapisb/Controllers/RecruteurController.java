package com.tekup.pfaapisb.Controllers;


import org.springframework.stereotype.Controller;

@Controller
public class RecruteurController {
}
