package com.tekup.pfaapisb.Repositories;

import com.tekup.pfaapisb.Models.Competence;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CompetenceRepository extends JpaRepository<Competence, Long> {

}
