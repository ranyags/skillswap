package com.tekup.pfaapisb.Enum;

public enum TokenType {
    BEARER
}
