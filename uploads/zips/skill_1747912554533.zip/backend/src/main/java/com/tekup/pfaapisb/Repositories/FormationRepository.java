package com.tekup.pfaapisb.Repositories;

import com.tekup.pfaapisb.Models.Formation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormationRepository extends JpaRepository<Formation, Integer> {
}
