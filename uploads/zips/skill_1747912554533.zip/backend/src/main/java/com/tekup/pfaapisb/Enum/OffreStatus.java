package com.tekup.pfaapisb.Enum;

public enum OffreStatus {
    OPEN,
    CLOSED
}
