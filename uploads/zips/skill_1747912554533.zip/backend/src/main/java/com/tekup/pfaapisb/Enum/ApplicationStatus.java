package com.tekup.pfaapisb.Enum;

public enum ApplicationStatus {
    Pending,
    Accepted,
    Rejected
}
