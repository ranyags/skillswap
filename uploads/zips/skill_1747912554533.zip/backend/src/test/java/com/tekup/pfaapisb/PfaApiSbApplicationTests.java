package com.tekup.pfaapisb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PfaApiSbApplicationTests {

    @Test
    void contextLoads() {
    }

}
